<!-- membuat footer -->
<footer class="py-3 bg-dark">
  <div class="container">
    <p class="m-0 text-center text-white">&copy; 2020 Irhas Candra Sagita</p>
  </div>
</footer>
</html>